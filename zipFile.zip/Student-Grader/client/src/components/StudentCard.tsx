import { type StudentWithMarks } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Trophy, Medal, Award, ArrowRight, Trash2 } from "lucide-react";
import { useLocation } from "wouter";
import { useDeleteStudent } from "@/hooks/use-students";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface StudentCardProps {
  student: StudentWithMarks;
  rank: number;
}

export function StudentCard({ student, rank }: StudentCardProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const deleteMutation = useDeleteStudent();

  const totalObtained = student.marks.reduce((sum, m) => sum + m.obtained, 0);
  const totalMax = student.marks.reduce((sum, m) => sum + m.max, 0);
  const percentage = totalMax > 0 ? (totalObtained / totalMax) * 100 : 0;

  const isTop3 = rank <= 3;
  const isTop10 = rank <= 10;
  
  let rankBadge = null;
  if (rank === 1) rankBadge = <Trophy className="w-5 h-5 text-yellow-500 fill-yellow-500" />;
  else if (rank === 2) rankBadge = <Medal className="w-5 h-5 text-slate-400 fill-slate-400" />;
  else if (rank === 3) rankBadge = <Medal className="w-5 h-5 text-amber-700 fill-amber-700" />;
  else if (isTop10) rankBadge = <Award className="w-5 h-5 text-blue-500" />;

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await deleteMutation.mutateAsync(student.id);
      toast({ title: "Student deleted", description: "Record removed successfully." });
    } catch (error) {
      toast({ title: "Error", description: "Could not delete student.", variant: "destructive" });
    }
  };

  return (
    <div 
      onClick={() => setLocation(`/student/${student.id}`)}
      className={`
        group relative overflow-hidden rounded-xl border bg-card text-card-foreground shadow-sm transition-all duration-300 hover:shadow-lg cursor-pointer
        ${rank === 1 ? 'border-yellow-500/50 shadow-yellow-500/10' : ''}
        ${rank === 2 ? 'border-slate-400/50 shadow-slate-400/10' : ''}
        ${rank === 3 ? 'border-amber-700/50 shadow-amber-700/10' : ''}
        ${rank > 3 && isTop10 ? 'border-blue-200 shadow-blue-500/5' : 'border-border/50'}
      `}
    >
      {/* Rank Indicator Stripe */}
      <div className={`absolute top-0 left-0 w-1.5 h-full 
        ${rank === 1 ? 'bg-gradient-to-b from-yellow-400 to-yellow-600' : ''}
        ${rank === 2 ? 'bg-gradient-to-b from-slate-300 to-slate-500' : ''}
        ${rank === 3 ? 'bg-gradient-to-b from-amber-600 to-amber-800' : ''}
        ${rank > 3 && isTop10 ? 'bg-blue-500' : 'bg-transparent'}
      `} />

      <div className="p-4 sm:p-5 flex items-center gap-4">
        {/* Rank Number */}
        <div className={`
          flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border
          ${isTop3 ? 'bg-white shadow-inner' : 'bg-muted/50 border-transparent'}
        `}>
          {rankBadge || <span className="text-muted-foreground">#{rank}</span>}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Roll No. {student.rollNo}
            </span>
            {isTop3 && <span className="px-2 py-0.5 text-[10px] font-bold bg-red-100 text-red-600 rounded-full uppercase">Top Ranker</span>}
          </div>
          <h3 className="font-heading text-lg font-bold truncate group-hover:text-primary transition-colors">
            {student.name}
          </h3>
        </div>

        {/* Stats */}
        <div className="text-right flex flex-col items-end gap-0.5">
          <div className="text-2xl font-bold tabular-nums tracking-tight">
            {percentage.toFixed(1)}<span className="text-sm text-muted-foreground ml-0.5">%</span>
          </div>
          <div className="text-xs text-muted-foreground font-medium">
            {totalObtained} / {totalMax}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 pl-2 border-l border-border/50 ml-2">
           <AlertDialog>
            <AlertDialogTrigger asChild>
              <button
                onClick={(e) => e.stopPropagation()}
                className="p-2 rounded-lg text-muted-foreground hover:bg-red-50 hover:text-red-600 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Student?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete {student.name} and all their marks.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={(e) => e.stopPropagation()}>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={handleDelete}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          
          <div className="p-2 rounded-lg bg-primary/5 text-primary group-hover:bg-primary group-hover:text-white transition-all">
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>
      </div>
    </div>
  );
}
