import { useEffect, useState, useMemo } from "react";
import { useParams, Link } from "wouter";
import { useStudent } from "@/hooks/use-students";
import { useUpdateMarks } from "@/hooks/use-marks";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Plus, Save, ArrowLeft, TrendingUp, Calendar, BookOpen, Calculator } from "lucide-react";
import { format } from "date-fns";
import type { Mark } from "@shared/schema";

// Type for editable mark entry - partial of Mark but with local ID for keys
interface EditableMark {
  localId: string; // purely for React keys
  id?: number; // DB id
  subject: string;
  date: string;
  obtained: number;
  max: number;
}

export default function StudentDetails() {
  const { id } = useParams();
  const studentId = Number(id);
  const { data: student, isLoading, error } = useStudent(studentId);
  const updateMutation = useUpdateMarks();
  const { toast } = useToast();

  const [marks, setMarks] = useState<EditableMark[]>([]);
  const [isDirty, setIsDirty] = useState(false);

  // Initialize marks state when data loads
  useEffect(() => {
    if (student) {
      const initialMarks = student.marks.map((m) => ({
        localId: `db-${m.id}`,
        id: m.id,
        subject: m.subject || "General",
        date: m.date || new Date().toISOString().split("T")[0],
        obtained: m.obtained,
        max: m.max,
      }));
      // If no marks, add one empty box to start
      if (initialMarks.length === 0) {
        initialMarks.push({
            localId: `new-${Date.now()}`,
            subject: "Test 1",
            date: new Date().toISOString().split("T")[0],
            obtained: 0,
            max: 100,
        });
      }
      setMarks(initialMarks);
    }
  }, [student]);

  const handleAddBox = () => {
    setMarks((prev) => [
      ...prev,
      {
        localId: `new-${Date.now()}`,
        subject: `Test ${prev.length + 1}`,
        date: new Date().toISOString().split("T")[0],
        obtained: 0,
        max: 100,
      },
    ]);
    setIsDirty(true);
  };

  const handleMarkChange = (index: number, field: keyof EditableMark, value: any) => {
    setMarks((prev) => {
      const newMarks = [...prev];
      newMarks[index] = { ...newMarks[index], [field]: value };
      return newMarks;
    });
    setIsDirty(true);
  };

  const handleRemoveBox = (index: number) => {
    setMarks(prev => prev.filter((_, i) => i !== index));
    setIsDirty(true);
  };

  const handleSave = async () => {
    try {
      // Prepare payload
      const payload = marks.map((m) => ({
        id: m.id, // Include ID if it exists (update), omit if new (insert)
        subject: m.subject,
        date: m.date,
        obtained: Number(m.obtained),
        max: Number(m.max),
      }));

      await updateMutation.mutateAsync({
        studentId,
        marks: payload,
      });

      toast({
        title: "Saved!",
        description: "Student marks have been updated.",
      });
      setIsDirty(false);
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message,
        variant: "destructive",
      });
    }
  };

  // Real-time calculations
  const stats = useMemo(() => {
    const totalObtained = marks.reduce((sum, m) => sum + Number(m.obtained || 0), 0);
    const totalMax = marks.reduce((sum, m) => sum + Number(m.max || 0), 0);
    const percentage = totalMax > 0 ? (totalObtained / totalMax) * 100 : 0;
    return { totalObtained, totalMax, percentage };
  }, [marks]);

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-6">
          <Skeleton className="h-20 w-full rounded-xl" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Skeleton className="h-48 w-full rounded-xl" />
            <Skeleton className="h-48 w-full rounded-xl" />
            <Skeleton className="h-48 w-full rounded-xl" />
          </div>
        </div>
      </Layout>
    );
  }

  if (error || !student) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center py-20">
           <h2 className="text-xl font-bold text-destructive mb-4">Student not found</h2>
           <Link href="/">
             <Button variant="outline">Go Back Home</Button>
           </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8 pb-20">
        {/* Sticky Stats Header */}
        <div className="sticky top-24 z-40 bg-white/95 backdrop-blur-md border border-border shadow-md rounded-2xl p-4 md:p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 transition-all animate-in fade-in slide-in-from-top-4">
          <div className="flex items-center gap-4">
             <Link href="/">
                <Button variant="ghost" size="icon" className="rounded-full hover:bg-slate-100">
                    <ArrowLeft className="w-5 h-5 text-muted-foreground" />
                </Button>
             </Link>
             <div>
                <h1 className="text-2xl font-heading font-bold text-primary">{student.name}</h1>
                <p className="text-sm text-muted-foreground font-medium">Roll No. {student.rollNo}</p>
             </div>
          </div>
          
          <div className="flex items-center gap-8 border-l border-border pl-8">
            <div className="text-center">
                <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Total Marks</p>
                <p className="text-xl font-bold font-mono text-foreground">{stats.totalObtained} <span className="text-sm text-muted-foreground">/ {stats.totalMax}</span></p>
            </div>
            <div className="text-center">
                <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Percentage</p>
                <div className="flex items-center gap-2">
                    <p className={`text-2xl font-bold tabular-nums ${stats.percentage >= 60 ? 'text-green-600' : stats.percentage >= 40 ? 'text-yellow-600' : 'text-red-600'}`}>
                        {stats.percentage.toFixed(2)}%
                    </p>
                    <TrendingUp className="w-4 h-4 text-muted-foreground" />
                </div>
            </div>
            <Button 
                onClick={handleSave} 
                size="lg"
                disabled={!isDirty || updateMutation.isPending}
                className={`ml-4 shadow-lg ${isDirty ? 'animate-pulse' : ''}`}
            >
                {updateMutation.isPending ? "Saving..." : "Save Changes"}
                <Save className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>

        {/* Marks Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {marks.map((mark, index) => (
            <Card key={mark.localId} className="group relative overflow-hidden transition-all hover:shadow-lg hover:border-primary/30 border-t-4 border-t-primary/10 hover:border-t-primary">
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={() => handleRemoveBox(index)}
                  className="p-1 hover:bg-red-50 text-red-400 hover:text-red-600 rounded"
                  title="Remove Entry"
                >
                  <span className="sr-only">Delete</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </button>
              </div>
              
              <div className="p-5 space-y-4">
                 <div className="flex items-center gap-2 mb-2">
                    <div className="p-2 bg-primary/5 rounded-lg text-primary">
                        <BookOpen className="w-4 h-4" />
                    </div>
                    <Input 
                        value={mark.subject}
                        onChange={(e) => handleMarkChange(index, "subject", e.target.value)}
                        className="font-bold border-none shadow-none p-0 h-auto focus-visible:ring-0 placeholder:text-muted-foreground/50 text-base"
                        placeholder="Subject Name"
                    />
                 </div>

                 <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    <Input 
                        type="date"
                        value={mark.date}
                        onChange={(e) => handleMarkChange(index, "date", e.target.value)}
                        className="h-8 text-xs text-muted-foreground border-border/50 bg-secondary/20"
                    />
                 </div>

                 <div className="pt-4 border-t border-border/50 grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                        <label className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">Obtained</label>
                        <div className="relative">
                            <Input 
                                type="number"
                                value={mark.obtained}
                                onChange={(e) => handleMarkChange(index, "obtained", Number(e.target.value))}
                                className="font-mono font-bold text-lg h-10 border-primary/20 focus:border-primary bg-primary/5"
                            />
                        </div>
                    </div>
                    <div className="space-y-1.5">
                        <label className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">Max</label>
                         <div className="relative">
                            <Input 
                                type="number"
                                value={mark.max}
                                onChange={(e) => handleMarkChange(index, "max", Number(e.target.value))}
                                className="font-mono text-lg h-10 bg-secondary/30 text-muted-foreground"
                            />
                        </div>
                    </div>
                 </div>
                 
                 {/* Mini percentage for this box */}
                 <div className="text-right text-[10px] text-muted-foreground font-medium pt-1">
                    {mark.max > 0 ? ((mark.obtained / mark.max) * 100).toFixed(0) : 0}%
                 </div>
              </div>
            </Card>
          ))}

          {/* Add New Button Card */}
          <button
            onClick={handleAddBox}
            className="flex flex-col items-center justify-center min-h-[240px] rounded-xl border-2 border-dashed border-primary/20 bg-primary/5 hover:bg-primary/10 hover:border-primary/40 transition-all group"
          >
            <div className="h-16 w-16 rounded-full bg-white shadow-sm flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Plus className="w-8 h-8 text-primary" />
            </div>
            <span className="font-bold text-primary text-lg">Add New Entry</span>
            <span className="text-sm text-primary/60 mt-1">Unlimited Boxes</span>
          </button>
        </div>
      </div>
    </Layout>
  );
}
