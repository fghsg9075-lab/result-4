import { Layout } from "@/components/Layout";
import { useStudents } from "@/hooks/use-students";
import { StudentCard } from "@/components/StudentCard";
import { CreateStudentDialog } from "@/components/CreateStudentDialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Home() {
  const { data: students, isLoading, error } = useStudents();
  const [search, setSearch] = useState("");

  if (error) {
    return (
      <Layout>
        <div className="text-center py-20">
          <h2 className="text-destructive text-xl font-bold">Error loading data</h2>
          <p className="text-muted-foreground">{error.message}</p>
        </div>
      </Layout>
    );
  }

  // Calculate percentages and sort
  const sortedStudents = students
    ? [...students].sort((a, b) => {
        const pA =
          a.marks.reduce((sum, m) => sum + m.max, 0) > 0
            ? (a.marks.reduce((sum, m) => sum + m.obtained, 0) /
                a.marks.reduce((sum, m) => sum + m.max, 0)) *
              100
            : 0;
        const pB =
          b.marks.reduce((sum, m) => sum + m.max, 0) > 0
            ? (b.marks.reduce((sum, m) => sum + m.obtained, 0) /
                b.marks.reduce((sum, m) => sum + m.max, 0)) *
              100
            : 0;
        return pB - pA; // Descending
      })
    : [];

  const filteredStudents = sortedStudents.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.rollNo.toString().includes(search)
  );

  return (
    <Layout>
      <div className="space-y-8">
        {/* Actions Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or roll number..."
              className="pl-10 bg-white shadow-sm border-border/50 focus:ring-primary/20"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <CreateStudentDialog />
        </div>

        {/* List Header */}
        <div className="flex items-center justify-between px-2">
          <h2 className="text-xl font-heading font-bold text-foreground">
            Student Rankings
          </h2>
          <span className="text-sm text-muted-foreground font-medium bg-secondary/50 px-3 py-1 rounded-full">
            Total Students: {filteredStudents.length}
          </span>
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-24 bg-white rounded-xl border border-border/50 p-4 flex items-center gap-4">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-48" />
                  <Skeleton className="h-3 w-24" />
                </div>
                <div className="space-y-2 flex flex-col items-end">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredStudents.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-border">
            <p className="text-muted-foreground">No students found.</p>
          </div>
        ) : (
          <div className="grid gap-4">
             <AnimatePresence>
              {filteredStudents.map((student, index) => (
                <motion.div
                  key={student.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <StudentCard
                    student={student}
                    rank={index + 1}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </Layout>
  );
}
