import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

const SEED_DATA = [
  { rollNo: 1, name: "Aakash Yadav", obtained: 54, max: 80 },
  { rollNo: 2, name: "Aryan Kumar", obtained: 51, max: 80 },
  { rollNo: 3, name: "Rahul Kumar", obtained: 70, max: 80 },
  { rollNo: 4, name: "Aman Kumar", obtained: 46, max: 80 },
  { rollNo: 5, name: "Prince Kumar", obtained: 0, max: 80 },
  { rollNo: 6, name: "Faiz Raza", obtained: 58, max: 80 },
  { rollNo: 7, name: "Meraj Alam", obtained: 0, max: 80 },
  { rollNo: 8, name: "Afroz", obtained: 0, max: 80 },
  { rollNo: 9, name: "Ismail", obtained: 0, max: 80 },
  { rollNo: 10, name: "Khusboo", obtained: 62, max: 80 },
  { rollNo: 11, name: "Salma Parveen", obtained: 0, max: 80 },
  { rollNo: 12, name: "Aaisha Khatoon", obtained: 49, max: 80 },
  { rollNo: 13, name: "Sahima", obtained: 0, max: 80 },
  { rollNo: 14, name: "Aashiya", obtained: 45, max: 80 },
  { rollNo: 15, name: "Shanzida", obtained: 36, max: 80 },
  { rollNo: 16, name: "Maimuna", obtained: 68, max: 80 },
  { rollNo: 17, name: "Soha", obtained: 56, max: 80 },
  { rollNo: 18, name: "Naziya (U)", obtained: 58, max: 80 },
  { rollNo: 19, name: "Jashmin", obtained: 56, max: 80 },
  { rollNo: 20, name: "Usha Kumari", obtained: 38, max: 80 },
  { rollNo: 21, name: "Gungun", obtained: 54, max: 80 },
  { rollNo: 22, name: "Naziya (D)", obtained: 45, max: 80 },
  { rollNo: 23, name: "Shahina Khatoon", obtained: 60, max: 80 },
  { rollNo: 24, name: "Sonam Kumari", obtained: 40, max: 80 },
  { rollNo: 25, name: "Farzana", obtained: 65, max: 80 },
  { rollNo: 26, name: "Muskan Khatoon", obtained: 53, max: 80 },
  { rollNo: 27, name: "Sabina", obtained: 60, max: 80 },
  { rollNo: 28, name: "Farhin", obtained: 0, max: 80 },
  { rollNo: 29, name: "Sanaa Parveen", obtained: 66, max: 80 },
  { rollNo: 30, name: "Rani Parveen", obtained: 56, max: 80 },
  { rollNo: 31, name: "Gulafsa", obtained: 68, max: 80 },
  { rollNo: 32, name: "Sajiya Khatoon", obtained: 54, max: 80 },
  { rollNo: 33, name: "Amarjit Kumar", obtained: 47, max: 80 },
  { rollNo: 34, name: "Prince Yadav", obtained: 21, max: 80 },
  { rollNo: 35, name: "Tabrez", obtained: 41, max: 80 },
  { rollNo: 36, name: "Faiz", obtained: 0, max: 80 },
  { rollNo: 37, name: "Muskan II", obtained: 0, max: 80 },
  { rollNo: 38, name: "Tahir", obtained: 40, max: 80 },
  { rollNo: 39, name: "Anshu Kumari", obtained: 0, max: 80 },
];

async function seedDatabase() {
  const students = await storage.getStudents();
  if (students.length === 0) {
    console.log("Seeding database...");
    for (const data of SEED_DATA) {
      const student = await storage.createStudent({
        rollNo: data.rollNo,
        name: data.name,
      });
      // Add the initial marks
      await storage.updateMarksForStudent(student.id, [{
        studentId: student.id,
        obtained: data.obtained,
        max: data.max,
        subject: "Initial Test",
        date: new Date().toISOString().split('T')[0]
      }]);
    }
    console.log("Seeding complete.");
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed data on startup
  seedDatabase();

  app.get(api.students.list.path, async (req, res) => {
    const students = await storage.getStudents();
    res.json(students);
  });

  app.get(api.students.get.path, async (req, res) => {
    const id = Number(req.params.id);
    const student = await storage.getStudent(id);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }
    res.json(student);
  });

  app.post(api.students.create.path, async (req, res) => {
    try {
      const input = api.students.create.input.parse(req.body);
      const student = await storage.createStudent(input);
      res.status(201).json(student);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.post(api.marks.bulkUpdate.path, async (req, res) => {
    try {
      const { studentId, marks } = api.marks.bulkUpdate.input.parse(req.body);
      const updatedMarks = await storage.updateMarksForStudent(studentId, marks);
      res.json(updatedMarks);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.students.delete.path, async (req, res) => {
     const id = Number(req.params.id);
     await storage.deleteStudent(id);
     res.status(204).send();
  });

  return httpServer;
}
