import { db } from "./db";
import {
  students,
  subjects,
  marks,
  type Student,
  type Subject,
  type Mark,
  type InsertStudent,
  type InsertSubject,
  type StudentWithMarks
} from "@shared/schema";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  getStudents(): Promise<StudentWithMarks[]>;
  getStudent(id: number): Promise<StudentWithMarks | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  
  getSubjects(): Promise<Subject[]>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  deleteSubject(id: number): Promise<void>;
  
  updateMark(studentId: number, subjectId: number, obtained: number): Promise<Mark>;
}

export class DatabaseStorage implements IStorage {
  async getStudents(): Promise<StudentWithMarks[]> {
    const allStudents = await db.select().from(students);
    const allSubjects = await db.select().from(subjects);
    const allMarks = await db.select().from(marks);

    return allStudents.map(s => {
      const studentMarks = allMarks
        .filter(m => m.studentId === s.id)
        .map(m => ({
          ...m,
          subject: allSubjects.find(sub => sub.id === m.subjectId)!
        }));
      return { ...s, marks: studentMarks };
    });
  }

  async getStudent(id: number): Promise<StudentWithMarks | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    if (!student) return undefined;

    const allSubjects = await db.select().from(subjects);
    const studentMarks = await db.select().from(marks)
      .where(eq(marks.studentId, id));
    
    return {
      ...student,
      marks: studentMarks.map(m => ({
        ...m,
        subject: allSubjects.find(sub => sub.id === m.subjectId)!
      }))
    };
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const [student] = await db.insert(students).values(insertStudent).returning();
    return student;
  }

  async getSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects);
  }

  async createSubject(insertSubject: InsertSubject): Promise<Subject> {
    const [subject] = await db.insert(subjects).values(insertSubject).returning();
    
    // Auto-create 0 marks for all existing students when a subject is added
    const allStudents = await db.select().from(students);
    if (allStudents.length > 0) {
      await db.insert(marks).values(
        allStudents.map(s => ({
          studentId: s.id,
          subjectId: subject.id,
          obtained: 0
        }))
      );
    }
    
    return subject;
  }

  async deleteSubject(id: number): Promise<void> {
    await db.delete(marks).where(eq(marks.subjectId, id));
    await db.delete(subjects).where(eq(subjects.id, id));
  }

  async updateMark(studentId: number, subjectId: number, obtained: number): Promise<Mark> {
    const [existing] = await db.select().from(marks).where(
      and(eq(marks.studentId, studentId), eq(marks.subjectId, subjectId))
    );

    if (existing) {
      const [updated] = await db.update(marks)
        .set({ obtained })
        .where(eq(marks.id, existing.id))
        .returning();
      return updated;
    } else {
      const [inserted] = await db.insert(marks)
        .values({ studentId, subjectId, obtained })
        .returning();
      return inserted;
    }
  }
}

export const storage = new DatabaseStorage();
