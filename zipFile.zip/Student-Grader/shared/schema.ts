import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// === TABLE DEFINITIONS ===
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  rollNo: integer("roll_no").notNull().unique(),
  name: text("name").notNull(),
});

// Subject definitions that apply to all students
export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  date: text("date"),
  maxMarks: integer("max_marks").notNull().default(100),
});

// Marks for a specific student and subject
export const marks = pgTable("marks", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  subjectId: integer("subject_id").notNull(),
  obtained: integer("obtained").notNull().default(0),
});

// === RELATIONS ===
export const studentsRelations = relations(students, ({ many }) => ({
  marks: many(marks),
}));

export const subjectsRelations = relations(subjects, ({ many }) => ({
  marks: many(marks),
}));

export const marksRelations = relations(marks, ({ one }) => ({
  student: one(students, {
    fields: [marks.studentId],
    references: [students.id],
  }),
  subject: one(subjects, {
    fields: [marks.subjectId],
    references: [subjects.id],
  }),
}));

// === BASE SCHEMAS ===
export const insertStudentSchema = createInsertSchema(students).omit({ id: true });
export const insertSubjectSchema = createInsertSchema(subjects).omit({ id: true });
export const insertMarkSchema = createInsertSchema(marks).omit({ id: true });

// === EXPLICIT API CONTRACT TYPES ===
export type Student = typeof students.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type Mark = typeof marks.$inferSelect;

export type StudentWithMarks = Student & { 
  marks: (Mark & { subject: Subject })[] 
};

// Request types
export type CreateSubjectRequest = z.infer<typeof insertSubjectSchema>;
export type UpdateMarkRequest = {
  studentId: number;
  subjectId: number;
  obtained: number;
};
